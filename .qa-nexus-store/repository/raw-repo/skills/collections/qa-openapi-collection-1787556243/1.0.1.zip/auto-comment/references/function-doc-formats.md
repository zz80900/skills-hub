# 函数文档格式参考

始终优先沿用仓库已经采用的格式。以下模板仅用于项目没有明确规范时；字段名称可替换为语言原生等价标签，但必须覆盖参数、返回值和异常三类信息。

## Java、Kotlin、JavaScript、TypeScript、C、C++、PHP

使用项目支持的 Javadoc、JSDoc 或 Doxygen 标签：

```text
/**
 * [一句话说明业务职责或设计目的。]
 *
 * @param name [业务语义和关键约束；无参数时写 Params: 无。]
 * @return [调用方可依赖的返回语义；无返回值时写 Returns: 无。]
 * @throws ErrorType [真实触发条件；无异常时写 Throws: 无。]
 */
```

不要为“无”创建无效的参数名或异常类型；使用普通文档行表达即可。

## C#

使用 XML 文档标签：

```text
/// <summary>[一句话说明业务职责或设计目的。]</summary>
/// <param name="name">[业务语义和关键约束。]</param>
/// <returns>[调用方可依赖的返回语义；无返回值时写“无”。]</returns>
/// <exception cref="ExceptionType">[真实触发条件。]</exception>
```

没有参数或异常时，在 `<summary>` 后使用普通 `Params: 无。`、`Throws: 无。` 文档行，不要伪造 XML 标签目标。

## Python

使用项目既有 docstring 风格；没有既有格式时使用：

```text
"""[一句话说明业务职责或设计目的。]

Params:
    name: [业务语义和关键约束；无参数时写“无”。]
Returns:
    [调用方可依赖的返回语义；无返回值时写“无”。]
Throws:
    ErrorType: [真实触发条件；无异常时写“无”。]
"""
```

## Go

保持 Go 文档首句以导出标识符开头，再追加紧凑字段：

```text
// FunctionName [说明业务职责或设计目的]。
// Params: [参数语义；无参数时写“无”。]
// Returns: [返回值或 error 对调用方的含义；无返回值时写“无”。]
// Throws: 无；Go 错误通过 error 返回，除非该函数可能 panic。
```

## Rust

沿用 rustdoc，并使用语言原生等价章节：

```text
/// [一句话说明业务职责或设计目的。]
///
/// # Params
/// [参数语义；无参数时写“无”。]
///
/// # Returns
/// [返回语义；无返回值时写“无”。]
///
/// # Throws
/// [说明 `Result::Err` 或 panic 条件；均无时写“无”。]
```

## 其他语言

先检查同仓库相邻文件和官方文档注释约定。使用能被该语言工具链识别的格式，并保证三类语义完整；不要为了统一外观破坏编译器、文档生成器或静态检查规则。
